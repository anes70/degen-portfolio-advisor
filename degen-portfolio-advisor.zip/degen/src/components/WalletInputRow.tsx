import React from "react";
import { Wallet, Coins, X } from "lucide-react";
import type { Network } from "../types/wallet";
import { truncateAddress } from "../utils/format";

export function WalletInputRow({
  network,
  placeholder,
  value,
  onChange,
  connected,
  onSubmit,
  onDisconnect,
  loading,
  gradient,
  ring,
}: {
  network: Network;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  connected: string | null;
  onSubmit: () => void;
  onDisconnect: () => void;
  loading: boolean;
  gradient: string;
  ring: string;
}) {
  const NetworkIcon = network === "solana" ? Coins : Wallet;
  return (
    <div>
      <div className={`flex items-center gap-2 rounded-xl border border-[#1f2937] bg-black/40 px-3 py-2.5 transition-all duration-300 ${ring} focus-within:ring-2`}>
        <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${gradient} flex items-center justify-center shrink-0`}>
          <NetworkIcon className="w-3.5 h-3.5 text-white/80" />
        </div>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !loading && onSubmit()}
          placeholder={placeholder}
          disabled={loading}
          className="flex-1 bg-transparent text-sm font-mono text-slate-200 placeholder:text-slate-600 outline-none min-w-0"
        />
        {connected ? (
          <button
            onClick={onDisconnect}
            className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors shrink-0"
            title="Déconnecter"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        ) : (
          <button
            onClick={onSubmit}
            disabled={loading || !value.trim()}
            className="shrink-0 text-xs font-semibold px-3 py-1.5 rounded-lg bg-white text-black hover:bg-cyan-300 hover:shadow-[0_0_16px_rgba(103,232,249,0.5)] transition-all duration-300 disabled:opacity-30 disabled:hover:bg-white disabled:hover:shadow-none"
          >
            Analyser
          </button>
        )}
      </div>
      {connected ? <p className="mt-1.5 text-[11px] font-mono text-slate-500 pl-1">Connecté : {truncateAddress(connected)}</p> : null}
    </div>
  );
}
