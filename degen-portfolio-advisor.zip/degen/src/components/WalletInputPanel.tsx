import React, { useState, useCallback } from "react";
import { AlertTriangle } from "lucide-react";
import { GlassPanel } from "./GlassPanel";
import { WalletInputRow } from "./WalletInputRow";
import { isValidSolanaAddress, isValidBaseAddress } from "../utils/validators";
import { usePortfolioStore } from "../store/portfolioStore";

export function WalletInputPanel() {
  const [solInput, setSolInput] = useState("");
  const [baseInput, setBaseInput] = useState("");
  const [localError, setLocalError] = useState<string | null>(null);

  const wallets = usePortfolioStore((s) => s.wallets);
  const loading = usePortfolioStore((s) => s.loading);
  const error = usePortfolioStore((s) => s.error);
  const connectWallet = usePortfolioStore((s) => s.connectWallet);
  const disconnectWallet = usePortfolioStore((s) => s.disconnectWallet);

  const handleSubmit = useCallback(
    (network: "solana" | "base", address: string) => {
      setLocalError(null);
      const validator = network === "solana" ? isValidSolanaAddress : isValidBaseAddress;
      if (!validator(address)) {
        setLocalError(
          network === "solana"
            ? "Adresse Solana invalide (format base58 attendu)."
            : "Adresse Base invalide (format 0x + 40 caractères hex attendu)."
        );
        return;
      }
      connectWallet(network, address);
    },
    [connectWallet]
  );

  return (
    <GlassPanel className="p-5 sm:p-6">
      <h2 className="text-xs uppercase tracking-[0.18em] text-slate-500 font-semibold mb-4">Connexion des portefeuilles</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <WalletInputRow
          network="solana"
          placeholder="Adresse wallet Solana (base58)"
          value={solInput}
          onChange={setSolInput}
          connected={wallets.solana}
          onSubmit={() => handleSubmit("solana", solInput)}
          onDisconnect={() => {
            disconnectWallet("solana");
            setSolInput("");
          }}
          loading={loading}
          gradient="from-purple-500/20 to-fuchsia-400/10"
          ring="focus-within:ring-purple-400/40 focus-within:border-purple-400/50"
        />
        <WalletInputRow
          network="base"
          placeholder="Adresse wallet Base (0x...)"
          value={baseInput}
          onChange={setBaseInput}
          connected={wallets.base}
          onSubmit={() => handleSubmit("base", baseInput)}
          onDisconnect={() => {
            disconnectWallet("base");
            setBaseInput("");
          }}
          loading={loading}
          gradient="from-blue-500/20 to-cyan-400/10"
          ring="focus-within:ring-blue-400/40 focus-within:border-blue-400/50"
        />
      </div>
      {localError ? (
        <div className="mt-4 flex items-center gap-2 text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          {localError}
        </div>
      ) : null}
      {error ? (
        <div className="mt-4 flex items-center gap-2 text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      ) : null}
    </GlassPanel>
  );
}
