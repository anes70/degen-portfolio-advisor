import React from "react";

export function GlassPanel({ className = "", children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={`backdrop-blur-xl bg-white/[0.02] border border-[#1f2937] rounded-2xl ${className}`}>
      {children}
    </div>
  );
}
