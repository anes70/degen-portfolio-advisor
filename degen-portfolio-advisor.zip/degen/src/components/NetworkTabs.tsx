import React from "react";
import type { Network } from "../types/wallet";

export function NetworkTabs({
  active,
  onChange,
  counts,
}: {
  active: Network;
  onChange: (n: Network) => void;
  counts: Record<Network, number>;
}) {
  const tabs: { key: Network; label: string }[] = [
    { key: "solana", label: "Écosystème Solana" },
    { key: "base", label: "Écosystème Base" },
  ];
  return (
    <div className="flex gap-2 p-1 rounded-xl bg-black/40 border border-[#1f2937] w-fit">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => onChange(tab.key)}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all duration-300 flex items-center gap-2 ${
            active === tab.key ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300"
          }`}
        >
          {tab.label}
          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-full ${active === tab.key ? "bg-white/10" : "bg-white/5"}`}>
            {counts[tab.key]}
          </span>
        </button>
      ))}
    </div>
  );
}
