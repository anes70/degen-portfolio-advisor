import React, { useState, useEffect } from "react";

export function EntryPriceInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const [local, setLocal] = useState(value.toString());

  useEffect(() => {
    setLocal(value.toString());
  }, [value]);

  return (
    <div className="flex items-center gap-1.5">
      <span className="text-slate-600 text-xs font-mono">$</span>
      <input
        type="number"
        step="any"
        value={local}
        onChange={(e) => setLocal(e.target.value)}
        onBlur={() => {
          const parsed = parseFloat(local);
          if (!Number.isNaN(parsed) && parsed >= 0) {
            onChange(parsed);
          } else {
            setLocal(value.toString());
          }
        }}
        className="w-24 bg-black/50 border border-[#1f2937] rounded-lg px-2 py-1 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-400/50 focus:ring-1 focus:ring-cyan-400/30"
      />
    </div>
  );
}
