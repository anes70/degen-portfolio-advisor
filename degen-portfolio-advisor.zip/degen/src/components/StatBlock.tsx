import React from "react";

export function StatBlock({
  label,
  value,
  sub,
  tone,
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: string;
}) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-[11px] uppercase tracking-[0.18em] text-slate-500 font-medium">{label}</span>
      <span className={`text-2xl sm:text-3xl font-bold font-mono tracking-tight ${tone || "text-slate-100"}`}>
        {value}
      </span>
      {sub ? <span className="text-xs text-slate-500 font-mono">{sub}</span> : null}
    </div>
  );
}
