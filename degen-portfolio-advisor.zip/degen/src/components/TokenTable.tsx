import React from "react";
import { Wallet } from "lucide-react";
import { TokenRow } from "./TokenRow";
import { usePortfolioStore } from "../store/portfolioStore";
import type { Network } from "../types/wallet";

export function TokenTable({ network }: { network: Network }) {
  const tokens = usePortfolioStore((s) => s.tokens[network]);
  const entryPrices = usePortfolioStore((s) => s.entryPrices);
  const setEntryPrice = usePortfolioStore((s) => s.setEntryPrice);

  if (tokens.length === 0) {
    return (
      <div className="py-16 flex flex-col items-center justify-center text-center gap-2">
        <Wallet className="w-8 h-8 text-slate-700 mb-1" />
        <p className="text-sm text-slate-500">Aucun token {network === "solana" ? "SPL" : "ERC-20"} chargé.</p>
        <p className="text-xs text-slate-600">
          Connecte un wallet {network === "solana" ? "Solana" : "Base"} ci-dessus pour lancer l'analyse.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[1080px]">
        <thead>
          <tr className="text-left border-b border-[#1f2937]">
            <th className="pb-3 pl-1 text-[10px] uppercase tracking-[0.14em] text-slate-500 font-semibold">Jeton</th>
            <th className="pb-3 text-[10px] uppercase tracking-[0.14em] text-slate-500 font-semibold">Solde</th>
            <th className="pb-3 text-[10px] uppercase tracking-[0.14em] text-slate-500 font-semibold">Prix actuel / entrée</th>
            <th className="pb-3 text-[10px] uppercase tracking-[0.14em] text-slate-500 font-semibold">Métriques on-chain</th>
            <th className="pb-3 text-[10px] uppercase tracking-[0.14em] text-slate-500 font-semibold">PnL réel</th>
            <th className="pb-3 pr-1 text-[10px] uppercase tracking-[0.14em] text-slate-500 font-semibold">Degen Advisor</th>
          </tr>
        </thead>
        <tbody>
          {tokens.map((token) => (
            <TokenRow
              key={token.id}
              token={token}
              entryPrice={entryPrices[token.id] ?? token.priceUsd}
              onEntryPriceChange={(value) => setEntryPrice(token.id, value)}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}
