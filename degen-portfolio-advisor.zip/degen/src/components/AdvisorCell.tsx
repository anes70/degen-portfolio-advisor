import React from "react";
import { Rocket, Zap, Waves, ShieldAlert, Activity, Skull, Search } from "lucide-react";
import type { AdvisorAnalysis } from "../types/advisor";

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Rocket,
  Zap,
  Waves,
  ShieldAlert,
  Activity,
  Skull,
  Search,
};

export function AdvisorCell({ analysis }: { analysis: AdvisorAnalysis }) {
  const { scenario, title, advice, score } = analysis;
  const IconEl = ICONS[scenario.iconName] ?? Search;
  return (
    <div className={`min-w-[280px] max-w-[380px] rounded-xl border px-3.5 py-3 ${scenario.cellBg}`}>
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${scenario.dot}`} />
          <IconEl className={`w-3.5 h-3.5 ${scenario.accentText}`} />
          <span className={`text-[11px] font-bold tracking-wide ${scenario.accentText}`}>{title}</span>
        </div>
        <span className="text-[10px] font-mono text-slate-500">{Math.round(score)}/100</span>
      </div>
      <p className="text-[12px] leading-relaxed text-slate-300">{advice}</p>
    </div>
  );
}
