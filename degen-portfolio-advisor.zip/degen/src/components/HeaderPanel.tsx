import React, { useMemo } from "react";
import { RefreshCw, Flame } from "lucide-react";
import { GlassPanel } from "./GlassPanel";
import { StatBlock } from "./StatBlock";
import { formatUsd, formatPercent } from "../utils/format";
import { usePortfolioStore } from "../store/portfolioStore";

export function HeaderPanel() {
  const tokens = usePortfolioStore((s) => s.tokens);
  const entryPrices = usePortfolioStore((s) => s.entryPrices);
  const refreshing = usePortfolioStore((s) => s.refreshing);
  const lastUpdated = usePortfolioStore((s) => s.lastUpdated);
  const refreshAll = usePortfolioStore((s) => s.refreshAll);

  const allTokens = useMemo(() => [...tokens.solana, ...tokens.base], [tokens]);

  const totalValue = useMemo(() => allTokens.reduce((sum, t) => sum + t.balance * t.priceUsd, 0), [allTokens]);

  const totalPnlUsd = useMemo(
    () =>
      allTokens.reduce((sum, t) => {
        const entry = entryPrices[t.id] ?? t.priceUsd;
        return sum + t.balance * (t.priceUsd - entry);
      }, 0),
    [allTokens, entryPrices]
  );

  const totalCostBasis = useMemo(
    () =>
      allTokens.reduce((sum, t) => {
        const entry = entryPrices[t.id] ?? t.priceUsd;
        return sum + t.balance * entry;
      }, 0),
    [allTokens, entryPrices]
  );

  const totalPnlPercent = totalCostBasis > 0 ? (totalPnlUsd / totalCostBasis) * 100 : 0;
  const pnlPositive = totalPnlUsd >= 0;

  return (
    <GlassPanel className="p-5 sm:p-7">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-fuchsia-500/20 to-cyan-400/20 border border-white/10 flex items-center justify-center">
            <Flame className="w-5 h-5 text-fuchsia-400" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-100">Degen Portfolio Tracker</h1>
            <p className="text-xs text-slate-500 font-mono">Momentum Advisor · Solana + Base · live simulation</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 sm:gap-10">
          <StatBlock label="Valeur totale" value={formatUsd(totalValue, { compact: totalValue > 1_000_000 })} />
          <StatBlock
            label="PnL global"
            value={`${pnlPositive ? "+" : ""}${formatUsd(totalPnlUsd, { compact: Math.abs(totalPnlUsd) > 1_000_000 })}`}
            sub={formatPercent(totalPnlPercent)}
            tone={pnlPositive ? "text-green-400" : "text-red-400"}
          />
          <div className="flex items-center">
            <RefreshCw className={`w-4 h-4 mr-2 text-slate-500 ${refreshing ? "animate-spin" : ""}`} />
            <button
              onClick={() => refreshAll()}
              disabled={refreshing}
              className="group relative px-4 py-2.5 rounded-xl bg-white/[0.03] border border-[#1f2937] text-sm font-medium text-slate-300 hover:text-white hover:border-cyan-400/40 hover:bg-cyan-400/5 transition-all duration-300 disabled:opacity-50"
            >
              {refreshing ? "Actualisation..." : "Rafraîchir"}
            </button>
          </div>
        </div>
      </div>

      {lastUpdated ? (
        <p className="text-[11px] text-slate-600 font-mono mt-4">
          Dernière synchro : {new Date(lastUpdated).toLocaleTimeString("fr-FR")} · auto-refresh toutes les 30s
        </p>
      ) : null}
    </GlassPanel>
  );
}
