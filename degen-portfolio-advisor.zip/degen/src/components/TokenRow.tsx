import React, { useMemo } from "react";
import { TrendingUp, TrendingDown } from "lucide-react";
import { EntryPriceInput } from "./EntryPriceInput";
import { AdvisorCell } from "./AdvisorCell";
import { analyzeTokenMomentum } from "../advisor/analyzeTokenMomentum";
import { formatUsd, formatPercent, formatTokenAmount } from "../utils/format";
import type { Token } from "../types/token";

export function TokenRow({
  token,
  entryPrice,
  onEntryPriceChange,
}: {
  token: Token;
  entryPrice: number;
  onEntryPriceChange: (v: number) => void;
}) {
  const analysis = useMemo(() => analyzeTokenMomentum(token, entryPrice), [token, entryPrice]);
  const { pnlPercent, dropAth, volLiqRatio } = analysis.metrics;
  const pnlUsd = token.balance * (token.priceUsd - entryPrice);
  const pnlPositive = pnlPercent >= 0;

  return (
    <tr className="border-b border-[#151a21] hover:bg-white/[0.015] transition-colors align-top">
      <td className="py-4 pr-4 pl-1">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-700 to-slate-800 border border-white/5 flex items-center justify-center text-[10px] font-bold text-slate-300">
            {token.symbol.slice(0, 3)}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-semibold text-slate-100">{token.symbol}</span>
              <span
                className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${
                  token.network === "solana"
                    ? "border-purple-400/30 text-purple-300 bg-purple-500/10"
                    : "border-blue-400/30 text-blue-300 bg-blue-500/10"
                }`}
              >
                {token.network === "solana" ? "SOL" : "BASE"}
              </span>
            </div>
            <span className="text-[11px] text-slate-500">{token.name}</span>
          </div>
        </div>
      </td>

      <td className="py-4 pr-4">
        <div className="text-xs font-mono text-slate-300">
          {formatTokenAmount(token.balance)} {token.symbol}
        </div>
        <div className="text-xs font-mono text-slate-500">{formatUsd(token.balance * token.priceUsd)}</div>
      </td>

      <td className="py-4 pr-4">
        <div className="text-xs font-mono text-slate-300 mb-1.5">{formatUsd(token.priceUsd)}</div>
        <EntryPriceInput value={entryPrice} onChange={onEntryPriceChange} />
      </td>

      <td className="py-4 pr-4">
        <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] font-mono">
          <span className="text-slate-500">Vol 24h</span>
          <span className="text-slate-300">{formatUsd(token.volume24h, { compact: true })}</span>
          <span className="text-slate-500">Liquidité</span>
          <span className="text-slate-300">{formatUsd(token.liquidityUsd, { compact: true })}</span>
          <span className="text-slate-500">Drop ATH</span>
          <span className="text-orange-300">-{dropAth.toFixed(1)}%</span>
          <span className="text-slate-500">Δ Vol 1h</span>
          <span className={token.volumeDelta1h >= 0 ? "text-green-400" : "text-red-400"}>{formatPercent(token.volumeDelta1h)}</span>
          <span className="text-slate-600">Vol/Liq</span>
          <span className="text-slate-600">{volLiqRatio.toFixed(2)}x</span>
        </div>
      </td>

      <td className="py-4 pr-4">
        <div className={`flex items-center gap-1 text-sm font-bold font-mono ${pnlPositive ? "text-green-400" : "text-red-400"}`}>
          {pnlPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
          {formatPercent(pnlPercent)}
        </div>
        <div className={`text-[11px] font-mono ${pnlPositive ? "text-green-500/70" : "text-red-500/70"}`}>
          {pnlPositive ? "+" : ""}
          {formatUsd(pnlUsd, { compact: Math.abs(pnlUsd) > 1_000_000 })}
        </div>
      </td>

      <td className="py-4 pr-1">
        <AdvisorCell analysis={analysis} />
      </td>
    </tr>
  );
}
