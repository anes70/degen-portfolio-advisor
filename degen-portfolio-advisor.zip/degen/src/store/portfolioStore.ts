import { create } from "zustand";
import { persist } from "zustand/middleware";
import { fetchSolanaAssets } from "../services/helius";
import { fetchBaseAssets } from "../services/base";
import { fetchDexscreenerMarketData } from "../services/dexscreener";
import { driftToken } from "../mocks/priceEngine";
import { hashStringToSeed } from "../utils/helpers";
import { REFRESH_INTERVAL_MS, ENTRY_PRICES_STORAGE_KEY } from "../utils/constants";
import type { Network } from "../types/wallet";
import type { Token } from "../types/token";

interface PortfolioStore {
  wallets: { solana: string | null; base: string | null };
  tokens: { solana: Token[]; base: Token[] };
  entryPrices: Record<string, number>;
  loading: boolean;
  refreshing: boolean;
  error: string | null;
  lastUpdated: number | null;

  connectWallet: (network: Network, address: string) => Promise<void>;
  disconnectWallet: (network: Network) => void;
  refreshMarketData: (network: Network) => Promise<void>;
  refreshAll: () => Promise<void>;
  setEntryPrice: (tokenId: string, value: number) => void;
}

export const usePortfolioStore = create<PortfolioStore>()(
  persist(
    (set, get) => ({
      wallets: { solana: null, base: null },
      tokens: { solana: [], base: [] },
      entryPrices: {},
      loading: false,
      refreshing: false,
      error: null,
      lastUpdated: null,

      connectWallet: async (network, address) => {
        set({ loading: true, error: null });
        try {
          const rawAssets = network === "solana" ? await fetchSolanaAssets(address) : await fetchBaseAssets(address);
          const seed = hashStringToSeed(address);
          const enriched: Token[] = await Promise.all(
            rawAssets.map(async (asset) => {
              const market = await fetchDexscreenerMarketData(asset, seed);
              return { ...asset, ...market };
            })
          );

          const nextEntryPrices = { ...get().entryPrices };
          enriched.forEach((t) => {
            if (nextEntryPrices[t.id] === undefined) {
              nextEntryPrices[t.id] = t.priceUsd * (0.55 + Math.random() * 0.9);
            }
          });

          set((state) => ({
            loading: false,
            error: null,
            wallets: { ...state.wallets, [network]: address },
            tokens: { ...state.tokens, [network]: enriched },
            entryPrices: nextEntryPrices,
            lastUpdated: Date.now(),
          }));
        } catch (err) {
          set({ loading: false, error: "Impossible de récupérer les données du portefeuille. Réessaie." });
        }
      },

      disconnectWallet: (network) => {
        set((state) => ({
          wallets: { ...state.wallets, [network]: null },
          tokens: { ...state.tokens, [network]: [] },
        }));
      },

      refreshMarketData: async (network) => {
        const current = get().tokens[network];
        if (current.length === 0) return;
        const tick = Math.floor(Date.now() / REFRESH_INTERVAL_MS);
        const updated = current.map((token) => driftToken(token, tick));
        set((state) => ({
          tokens: { ...state.tokens, [network]: updated },
          lastUpdated: Date.now(),
        }));
      },

      refreshAll: async () => {
        set({ refreshing: true });
        await Promise.all([get().refreshMarketData("solana"), get().refreshMarketData("base")]);
        set({ refreshing: false });
      },

      setEntryPrice: (tokenId, value) => {
        set((state) => ({ entryPrices: { ...state.entryPrices, [tokenId]: value } }));
      },
    }),
    {
      name: ENTRY_PRICES_STORAGE_KEY,
      partialize: (state) => ({ entryPrices: state.entryPrices }),
    }
  )
);
