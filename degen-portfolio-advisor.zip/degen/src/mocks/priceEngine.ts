import { generateMarketSnapshot } from "./marketData";
import { hashStringToSeed } from "../utils/helpers";
import type { Token } from "../types/token";

/**
 * Fait "vivre" un token entre deux cycles de polling : légère marche
 * aléatoire du prix, volume et liquidité, pour un rendu réaliste sans
 * appel réseau réel.
 */
export function driftToken(token: Token, tick: number): Token {
  const market = generateMarketSnapshot(token, hashStringToSeed(token.address) + tick);
  const drift = 1 + (Math.random() - 0.5) * 0.08;
  const nextPrice = Math.max(token.priceUsd * drift, 0.0000001);
  return {
    ...token,
    priceUsd: nextPrice,
    volume24h: Math.max(market.volume24h * (0.85 + Math.random() * 0.3), 1000),
    liquidityUsd: Math.max(market.liquidityUsd * (0.9 + Math.random() * 0.2), 1000),
    ath: Math.max(token.ath, nextPrice),
    volumeDelta1h: market.volumeDelta1h,
  };
}
