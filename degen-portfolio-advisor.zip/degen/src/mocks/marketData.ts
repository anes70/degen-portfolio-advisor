import { mulberry32, hashStringToSeed } from "../utils/helpers";
import type { DexscreenerResponse } from "../types/market";
import type { RawAsset } from "../types/token";

/**
 * Génère un instantané de marché simulé pour un token donné.
 * En production, remplace le corps de cette fonction par un vrai appel
 * Dexscreener (voir src/services/dexscreener.ts pour le format exact).
 */
export function generateMarketSnapshot(token: RawAsset, seed: number): DexscreenerResponse {
  const rand = mulberry32(seed + hashStringToSeed(token.address));
  const basePrice = 0.00001 + rand() * 3;
  const liquidity = 50_000 + rand() * 4_000_000;
  const volume24h = liquidity * (0.1 + rand() * 3);
  const ath = basePrice * (1 + rand() * 4);
  const volumeDelta1h = (rand() - 0.4) * 160;
  return { priceUsd: basePrice, volume24h, liquidityUsd: liquidity, ath, volumeDelta1h };
}
