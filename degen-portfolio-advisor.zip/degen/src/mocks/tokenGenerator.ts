import { mulberry32, hashStringToSeed } from "../utils/helpers";
import { fakeAddressFor } from "./wallets";
import type { RawAsset } from "../types/token";

const MOCK_SOLANA_TOKEN_POOL = [
  { symbol: "WIF", name: "dogwifhat", decimals: 6 },
  { symbol: "BONK", name: "Bonk", decimals: 5 },
  { symbol: "POPCAT", name: "Popcat", decimals: 9 },
  { symbol: "PNUT", name: "Peanut the Squirrel", decimals: 6 },
  { symbol: "MEW", name: "cat in a dogs world", decimals: 5 },
  { symbol: "GOAT", name: "Goatseus Maximus", decimals: 6 },
  { symbol: "MOODENG", name: "Moo Deng", decimals: 6 },
  { symbol: "SLERF", name: "Slerf", decimals: 9 },
  { symbol: "JUP", name: "Jupiter", decimals: 6 },
  { symbol: "RAY", name: "Raydium", decimals: 6 },
];

const MOCK_BASE_TOKEN_POOL = [
  { symbol: "BRETT", name: "Brett", decimals: 18 },
  { symbol: "DEGEN", name: "Degen", decimals: 18 },
  { symbol: "TOSHI", name: "Toshi", decimals: 18 },
  { symbol: "AERO", name: "Aerodrome Finance", decimals: 18 },
  { symbol: "NORMIE", name: "Normie", decimals: 18 },
  { symbol: "MOCHI", name: "Mochi", decimals: 18 },
  { symbol: "KEYCAT", name: "Keyboard Cat", decimals: 18 },
  { symbol: "BALD", name: "Bald", decimals: 18 },
];

export function generateSolanaAssets(walletAddress: string): RawAsset[] {
  const seed = hashStringToSeed(walletAddress);
  const rand = mulberry32(seed);
  const tokenCount = 3 + Math.floor(rand() * 4);
  const pool = [...MOCK_SOLANA_TOKEN_POOL].sort(() => rand() - 0.5).slice(0, tokenCount);
  return pool.map((t) => {
    const address = fakeAddressFor("solana", t.symbol, seed);
    const rawBalance = Math.floor(rand() * 5_000_000) + 100;
    return {
      id: `sol-${address}`,
      network: "solana" as const,
      symbol: t.symbol,
      name: t.name,
      address,
      decimals: t.decimals,
      balance: rawBalance / 10 ** Math.min(t.decimals, 4),
    };
  });
}

export function generateBaseAssets(walletAddress: string): RawAsset[] {
  const seed = hashStringToSeed(walletAddress) + 7919;
  const rand = mulberry32(seed);
  const tokenCount = 2 + Math.floor(rand() * 4);
  const pool = [...MOCK_BASE_TOKEN_POOL].sort(() => rand() - 0.5).slice(0, tokenCount);
  return pool.map((t) => {
    const address = fakeAddressFor("base", t.symbol, seed);
    const rawBalance = Math.floor(rand() * 800_000) + 50;
    return {
      id: `base-${address}`,
      network: "base" as const,
      symbol: t.symbol,
      name: t.name,
      address,
      decimals: t.decimals,
      balance: rawBalance / 100,
    };
  });
}
