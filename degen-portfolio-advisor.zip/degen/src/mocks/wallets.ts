import { mulberry32, hashStringToSeed } from "../utils/helpers";
import type { Network } from "../types/wallet";

export function fakeAddressFor(network: Network, symbol: string, seed: number): string {
  const rand = mulberry32(seed + hashStringToSeed(symbol));
  if (network === "solana") {
    const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    let out = "";
    for (let i = 0; i < 44; i++) out += alphabet[Math.floor(rand() * alphabet.length)];
    return out;
  }
  const hex = "0123456789abcdef";
  let out = "0x";
  for (let i = 0; i < 40; i++) out += hex[Math.floor(rand() * hex.length)];
  return out;
}
