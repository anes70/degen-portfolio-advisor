export function calculateVolLiqRatio(volume24h: number, liquidityUsd: number): number {
  if (!liquidityUsd || liquidityUsd <= 0) return 0;
  return volume24h / liquidityUsd;
}

export function calculateDropFromAth(priceUsd: number, ath: number): number {
  if (!ath || ath <= 0) return 0;
  return ((ath - priceUsd) / ath) * 100;
}
