import { calculatePnlPercent } from "./pnl";
import { calculateVolLiqRatio, calculateDropFromAth } from "./risk";
import { computeMomentumScore } from "./scoreEngine";
import type { Token } from "../types/token";
import type { AdvisorAnalysis, SignalStyle } from "../types/advisor";

export const SIGNAL_STYLES: Record<string, SignalStyle> = {
  PARABOLIC: {
    key: "PARABOLIC",
    label: "PARABOLE IMPLACABLE",
    cellBg: "bg-green-500/10 border-green-400/30",
    dot: "bg-green-400 animate-pulse shadow-[0_0_12px_2px_rgba(74,222,128,0.8)]",
    accentText: "text-green-400",
    iconName: "Rocket",
  },
  TAKE_PROFIT: {
    key: "TAKE_PROFIT",
    label: "RÈGLE D'OR DU DEGEN",
    cellBg: "bg-blue-500/10 border-blue-400/30",
    dot: "bg-blue-400 shadow-[0_0_10px_2px_rgba(96,165,250,0.7)]",
    accentText: "text-blue-400",
    iconName: "Zap",
  },
  HEALTHY_DIP: {
    key: "HEALTHY_DIP",
    label: "REPLI SAIN EN BULL MARKET",
    cellBg: "bg-emerald-900/20 border-emerald-600/30",
    dot: "bg-emerald-500 shadow-[0_0_10px_2px_rgba(16,185,129,0.6)]",
    accentText: "text-emerald-400",
    iconName: "Waves",
  },
  LIQUIDITY_TRAP: {
    key: "LIQUIDITY_TRAP",
    label: "PIÈGE DE LIQUIDITÉ",
    cellBg: "bg-orange-500/10 border-orange-400/30",
    dot: "bg-orange-400 shadow-[0_0_10px_2px_rgba(251,146,60,0.7)]",
    accentText: "text-orange-400",
    iconName: "ShieldAlert",
  },
  VOLUME_SHOCK: {
    key: "VOLUME_SHOCK",
    label: "CHOC DE VOLUMES HORAIRES",
    cellBg: "bg-purple-500/10 border-purple-400/30",
    dot: "bg-purple-400 shadow-[0_0_10px_2px_rgba(192,132,252,0.7)]",
    accentText: "text-purple-400",
    iconName: "Activity",
  },
  CAPITULATION: {
    key: "CAPITULATION",
    label: "CAPITULATION",
    cellBg: "bg-red-500/10 border-red-400/30",
    dot: "bg-red-500 shadow-[0_0_10px_2px_rgba(239,68,68,0.7)]",
    accentText: "text-red-400",
    iconName: "Skull",
  },
  NEUTRAL: {
    key: "NEUTRAL",
    label: "SIGNAL NEUTRE",
    cellBg: "bg-slate-500/5 border-slate-600/30",
    dot: "bg-slate-500",
    accentText: "text-slate-400",
    iconName: "Search",
  },
};

/**
 * Moteur "Degen Advisor V2" — fonction pure.
 * Croise PnL, ratio Volume/Liquidité, distance à l'ATH et delta de volume
 * horaire pour retourner un signal parmi 6 scénarios (+ un fallback neutre).
 */
export function analyzeTokenMomentum(token: Token, entryPrice: number): AdvisorAnalysis {
  const { priceUsd, volume24h, liquidityUsd, ath, volumeDelta1h } = token;

  const pnlPercent = calculatePnlPercent(priceUsd, entryPrice);
  const volLiqRatio = calculateVolLiqRatio(volume24h, liquidityUsd);
  const dropAth = calculateDropFromAth(priceUsd, ath);
  const metrics = { pnlPercent, volLiqRatio, dropAth, volumeDelta1h };

  let scenario: SignalStyle;
  let title: string;
  let advice: string;

  if (pnlPercent >= 20 && pnlPercent <= 500 && volume24h > 10_000_000 && volumeDelta1h > 25 && dropAth <= 15) {
    scenario = SIGNAL_STYLES.PARABOLIC;
    title = "MOMENTUM SUPRASONIQUE";
    advice = "Le marché refuse de corriger profondément car la demande absorbe instantanément l'offre (front-running permanent). Ne vends surtout pas. Si tu veux renforcer, fais-le uniquement via des micro-achats (DCA) sur les respirations de 5-10%. Cible psychologique très haute.";
  } else if (pnlPercent >= 100) {
    scenario = SIGNAL_STYLES.TAKE_PROFIT;
    title = "ALERTE SÉCURISATION DU CAPITAL";
    advice = "Tu as officiellement atteint un x2 net. La discipline surpasse l'avidité : vends exactement 50% de ta position maintenant pour extraire ton capital initial. Laisse courir les 50% restants (moonbag) vers le milliard l'esprit 100% serein.";
  } else if (volume24h > 5_000_000 && dropAth >= 15 && dropAth <= 35 && volumeDelta1h >= 0) {
    scenario = SIGNAL_STYLES.HEALTHY_DIP;
    title = "CORRECTION TECHNIQUE ULTRA-SAINE";
    advice = "Ce repli de 20-30% est une respiration vitale. Le volume élevé prouve que les baleines accumulent le panic-sell du retail. Zone optimale pour moyenner ton prix d'entrée à la hausse (DCA) avant la prochaine jambe verticale.";
  } else if (dropAth < 10 && (volumeDelta1h <= -50 || volLiqRatio < 0.2)) {
    scenario = SIGNAL_STYLES.LIQUIDITY_TRAP;
    title = "DANGER - ILLUSION HAUSSIÈRE";
    advice = "Le prix tient en façade mais le moteur (le volume) est totalement vide. Manque cruel de carburant. Risque de dump violent ou de retournement dès que les market makers CEX couperont les algos. Interdiction stricte de recharger ici.";
  } else if (volumeDelta1h > 100) {
    scenario = SIGNAL_STYLES.VOLUME_SHOCK;
    title = "ANOMALIE DE LIQUIDITÉ";
    advice = "Pic de volume horaire thermonucléaire détecté on-chain. Quelqu'un est en train de charger massivement ou un exchange prépare ses portefeuilles de test pour un listing imminent. Reste scotché aux graphiques, la volatilité va être légendaire.";
  } else if (pnlPercent <= -40 || (dropAth > 60 && volumeDelta1h < 0)) {
    scenario = SIGNAL_STYLES.CAPITULATION;
    title = "EFFONDREMENT DU NARRATIF";
    advice = "Le token a perdu sa force relative et la liquidité fuit la pool. Évalue froidement la situation : coupe immédiatement pour sauver tes derniers capitaux si le projet est un scam pur, ou accepte psychologiquement que ce bag devienne un investissement mort à long terme.";
  } else {
    scenario = SIGNAL_STYLES.NEUTRAL;
    title = "SURVEILLANCE EN COURS";
    advice = "Aucune configuration multi-facteurs extrême n'est détectée pour le moment : le prix, le volume et la distance à l'ATH ne convergent pas vers un signal fort. Continue de surveiller le delta de volume horaire, c'est souvent le premier indicateur à bouger.";
  }

  const score = computeMomentumScore(scenario.key, metrics);
  return { scenario, title, advice, metrics, score };
}
