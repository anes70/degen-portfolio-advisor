import type { ScenarioKey, MomentumMetrics } from "../types/advisor";

/**
 * Score global 0-100 dérivé des mêmes métriques que le moteur de scénarios.
 * Sert d'indicateur visuel synthétique en plus du conseil textuel détaillé.
 */
export function computeMomentumScore(scenario: ScenarioKey, metrics: MomentumMetrics): number {
  const { pnlPercent, dropAth, volumeDelta1h } = metrics;

  switch (scenario) {
    case "PARABOLIC":
      return Math.min(100, 85 + Math.min(volumeDelta1h / 10, 15));
    case "TAKE_PROFIT":
      return Math.min(100, 70 + Math.min(pnlPercent / 20, 20));
    case "HEALTHY_DIP":
      return 55 + Math.max(0, 10 - Math.abs(dropAth - 25) / 2);
    case "VOLUME_SHOCK":
      return 60;
    case "LIQUIDITY_TRAP":
      return Math.max(5, 30 - Math.abs(volumeDelta1h) / 10);
    case "CAPITULATION":
      return Math.max(0, 15 + pnlPercent / 10);
    case "NEUTRAL":
    default:
      return 45;
  }
}
