export function calculatePnlPercent(priceUsd: number, entryPrice: number): number {
  if (!entryPrice || entryPrice <= 0) return 0;
  return ((priceUsd - entryPrice) / entryPrice) * 100;
}

export function calculatePnlUsd(balance: number, priceUsd: number, entryPrice: number): number {
  return balance * (priceUsd - entryPrice);
}
