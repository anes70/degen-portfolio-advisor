import { REFRESH_INTERVAL_MS } from "../utils/constants";

/**
 * Petit utilitaire de polling générique : exécute `callback` toutes les
 * REFRESH_INTERVAL_MS ms et retourne une fonction de nettoyage (à appeler
 * dans le useEffect cleanup).
 */
export function startPolling(callback: () => void, intervalMs: number = REFRESH_INTERVAL_MS): () => void {
  const id = setInterval(callback, intervalMs);
  return () => clearInterval(id);
}
