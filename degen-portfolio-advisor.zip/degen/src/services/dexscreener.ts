import { generateMarketSnapshot } from "../mocks/marketData";
import type { RawAsset } from "../types/token";
import type { DexscreenerResponse } from "../types/market";

/**
 * MARKET DATA LAYER — simule Dexscreener :
 *
 *   GET https://api.dexscreener.com/tokens/v1/solana/<TOKEN_ADDRESS>
 *   GET https://api.dexscreener.com/tokens/v1/base/<TOKEN_ADDRESS>
 *
 * Réponse typique : priceUsd, volume.h24, priceChange.h1, liquidity.usd.
 * L'ATH n'est pas natif à Dexscreener : à dériver toi-même (max glissant
 * stocké côté backend/DB au fil du temps). Ici on le simule.
 */
export async function fetchDexscreenerMarketData(token: RawAsset, seed: number): Promise<DexscreenerResponse> {
  return generateMarketSnapshot(token, seed);
}
