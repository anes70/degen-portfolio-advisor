import { generateSolanaAssets } from "../mocks/tokenGenerator";
import { simulateNetworkDelay } from "../utils/helpers";
import type { RawAsset } from "../types/token";

/**
 * SOLANA LAYER — simule l'API Helius DAS (Digital Asset Standard) :
 *
 *   POST https://mainnet.helius-rpc.com/?api-key=VOTRE_CLE_HELIUS
 *   Content-Type: application/json
 *   {
 *     "jsonrpc": "2.0",
 *     "id": "portfolio-fetch",
 *     "method": "getAssetsByOwner",
 *     "params": {
 *       "ownerAddress": "<WALLET_ADDRESS>",
 *       "page": 1,
 *       "limit": 1000,
 *       "displayOptions": { "showFungible": true }
 *     }
 *   }
 *
 * result.items[].token_info.{balance, decimals} -> balance / 10**decimals
 * pour obtenir le solde humain.
 *
 * Pour brancher le vrai appel, remplace le corps de cette fonction par :
 *
 *   const res = await fetch(`https://mainnet.helius-rpc.com/?api-key=${import.meta.env.VITE_HELIUS_API_KEY}`, {
 *     method: "POST",
 *     headers: { "Content-Type": "application/json" },
 *     body: JSON.stringify({
 *       jsonrpc: "2.0", id: "portfolio-fetch", method: "getAssetsByOwner",
 *       params: { ownerAddress: walletAddress, page: 1, limit: 1000, displayOptions: { showFungible: true } },
 *     }),
 *   });
 *   const json = await res.json();
 *   return json.result.items.map(...) // mapper vers RawAsset[]
 */
export async function fetchSolanaAssets(walletAddress: string): Promise<RawAsset[]> {
  await simulateNetworkDelay();
  return generateSolanaAssets(walletAddress);
}
