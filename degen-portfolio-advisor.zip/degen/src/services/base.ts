import { generateBaseAssets } from "../mocks/tokenGenerator";
import { simulateNetworkDelay } from "../utils/helpers";
import type { RawAsset } from "../types/token";

/**
 * BASE LAYER — simule l'API Moralis (alternative : Alchemy) :
 *
 *   GET https://deep-index.moralis.io/api/v2.2/wallets/<WALLET_ADDRESS>/tokens?chain=base
 *   Headers: { "X-API-Key": "VOTRE_CLE_MORALIS" }
 *
 * Alternative Alchemy :
 *   POST https://base-mainnet.g.alchemy.com/v2/VOTRE_CLE_ALCHEMY
 *   { "jsonrpc":"2.0","method":"alchemy_getTokenBalances","params":["<WALLET_ADDRESS>"] }
 *
 * IMPORTANT : n'appelle jamais ces endpoints directement depuis le
 * navigateur avec ta clé API en clair (elle serait visible dans le bundle
 * JS). Passe par une petite fonction serverless (Vercel/Cloudflare) qui
 * détient la clé côté serveur et que ton front appelle à la place.
 */
export async function fetchBaseAssets(walletAddress: string): Promise<RawAsset[]> {
  await simulateNetworkDelay();
  return generateBaseAssets(walletAddress);
}
