export const REFRESH_INTERVAL_MS = 30000;

export const NETWORKS = {
  SOLANA: "solana" as const,
  BASE: "base" as const,
};

export const ENTRY_PRICES_STORAGE_KEY = "degen-portfolio:entry-prices";
