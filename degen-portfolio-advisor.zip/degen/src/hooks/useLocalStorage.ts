import { useEffect, useState } from "react";

/**
 * Hook générique de persistance localStorage (utilisable indépendamment du
 * store Zustand, par exemple pour des préférences UI simples).
 */
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? (JSON.parse(item) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Stockage indisponible (mode privé, quota dépassé...) : on ignore
      // silencieusement, l'app continue de fonctionner en mémoire.
    }
  }, [key, value]);

  return [value, setValue];
}
