import { useEffect, useRef } from "react";

/**
 * Exécute `callback` toutes les `intervalMs` ms tant que le composant qui
 * l'utilise est monté. `callback` peut être mis à jour librement entre les
 * rendus sans redémarrer l'intervalle (pattern "latest ref").
 */
export function usePolling(callback: () => void, intervalMs: number): void {
  const savedCallback = useRef(callback);

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    const id = setInterval(() => savedCallback.current(), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
}
