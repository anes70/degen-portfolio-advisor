export type ScenarioKey =
  | "PARABOLIC"
  | "TAKE_PROFIT"
  | "HEALTHY_DIP"
  | "LIQUIDITY_TRAP"
  | "VOLUME_SHOCK"
  | "CAPITULATION"
  | "NEUTRAL";

export interface SignalStyle {
  key: ScenarioKey;
  label: string;
  cellBg: string;
  dot: string;
  accentText: string;
  iconName: string;
}

export interface MomentumMetrics {
  pnlPercent: number;
  volLiqRatio: number;
  dropAth: number;
  volumeDelta1h: number;
}

export interface AdvisorAnalysis {
  scenario: SignalStyle;
  title: string;
  advice: string;
  metrics: MomentumMetrics;
  score: number;
}
