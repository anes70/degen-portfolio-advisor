import type { Token } from "./token";

export interface PortfolioState {
  wallets: { solana: string | null; base: string | null };
  tokens: { solana: Token[]; base: Token[] };
  entryPrices: Record<string, number>;
  loading: boolean;
  refreshing: boolean;
  error: string | null;
  lastUpdated: number | null;
}
