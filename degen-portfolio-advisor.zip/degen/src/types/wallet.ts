export type Network = "solana" | "base";

export interface WalletState {
  solana: string | null;
  base: string | null;
}
