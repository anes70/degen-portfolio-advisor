export interface DexscreenerResponse {
  priceUsd: number;
  volume24h: number;
  liquidityUsd: number;
  ath: number;
  volumeDelta1h: number;
}
