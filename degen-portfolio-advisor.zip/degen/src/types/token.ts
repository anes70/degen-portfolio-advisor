import type { Network } from "./wallet";

export interface RawAsset {
  id: string;
  network: Network;
  symbol: string;
  name: string;
  address: string;
  decimals: number;
  balance: number;
}

export interface MarketSnapshot {
  priceUsd: number;
  volume24h: number;
  liquidityUsd: number;
  ath: number;
  volumeDelta1h: number;
}

export type Token = RawAsset & MarketSnapshot;
